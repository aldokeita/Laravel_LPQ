<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e($title); ?></h1>
            <a href="<?php echo e(route('infaq.create')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><b>+</b> Tambah <?php echo e($title); ?></a>
        </div>

        <!-- DataTales Example -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Tabel <?php echo e($title); ?></h6>
            </div>
            <div class="card-body">
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger alert dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session()->has('success')): ?>
                    <div class="alert alert-danger alert dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table " id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>no</th>
                                <th>Tanggal</th>
                                <th>Siswa</th>
                                <th>Nominal</th>
                                <th>Payment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($data->bulan); ?>, <?php echo e($data->tahun); ?></td>
                                <td><?php echo e($data->siswa->nama); ?></td>
                                <td>Rp. <?php echo e($data->nominal); ?></td>
                                <?php if($data->payment): ?>
                                <td> Lunas</td>
                                <?php else: ?>
                                <td>
                                    <form action="<?php echo e(route('paymentinfaq',$data->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <input type="hidden" value="<?php echo e($data->id); ?>" name="id_infaq">
                                        <button class="btn btn-danger" onclick="return confirm('Apakah Sudah di Bayar ?')">Pay</button>
                                    </form>
                                </td>
                                <?php endif; ?>
                                <td style="text-align:">
                                    <form action="<?php echo e(route('infaq.destroy',$data->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        
                                        <button class="badge bg-danger border-0" onclick="return confirm('Hapus Data ?')"><i class="bi bi-trash3"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webapps/resources/views/dashboard/page/infaq/index.blade.php ENDPATH**/ ?>