<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e($title); ?></h1>
            <a href="/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><-Back</a>
        </div>

        

        <div class="col-6">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="div -invalid-feedback">
                    <div class="alert alert-danger alert dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="div -invalid-feedback">
                    <div class="alert alert-danger alert dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <form method="POST" action="<?php echo e(route('jadwal.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                

                <div class="mb-3">
                <label class="form-label" for="tanggal">Tanggal:</label>
                <input class="form-control" type="date" name="tanggal" required>
                </div>

                <div class="mb-3">
                <label class="form-label" for="jam_mulai">Jam Mulai:</label>
                <input class="form-control" type="time" name="jam_mulai" required>
                </div>

                <div class="mb-3">
                <label class="form-label" for="jam_akhir">Jam Akhir:</label>
                <input class="form-control" type="time" name="jam_akhir" required>
                </div>

                <div class="mb-3">
                    <label for="disabledSelect" class="form-label">kelas</label>
                    <select id="disabledSelect" class="form-select" name="kelas_id" >
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->kelas); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                <button type="submit" class="btn btn-primary">Submit</button>
                </div>


            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webapps/resources/views/dashboard/page/jadwal/add.blade.php ENDPATH**/ ?>