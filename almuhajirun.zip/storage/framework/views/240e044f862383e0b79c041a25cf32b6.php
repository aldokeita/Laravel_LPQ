<?php $__env->startSection('title','News'); ?>

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Detail News</h1>
    </div>
    <a href="<?php echo e(route('news.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><b><-</b> Back</a>
    <a href="<?php echo e(route('news.edit',$news->id)); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="bi bi-pencil-fill"></i>  Edit</a>
    <form action="<?php echo e(route('news.destroy',$news->id)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>

        <button class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onclick="return confirm('Hapus berita ?')" type="submit">
            <i class="bi bi-trash3"></i>  Delete
        </button>
    </form>

    <div class="m-10" style="text-align:center">


    <h3><?php echo e($news->title); ?></h3>
    <img src="<?php echo e(asset('storage/'.$news->photo)); ?>" alt="" width="350px">
    <br>
    <small>Author By : <?php echo e($news->user->name); ?></small>
    <br>
    <small>Category : <?php echo e($news->category->category); ?></small>
    <p><?php echo e($news->content); ?></p>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webapps/resources/views/dashboard/page/news/detailnews.blade.php ENDPATH**/ ?>