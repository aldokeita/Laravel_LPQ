<?php $__env->startSection('title','Add-Siswa'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">ADD NEWS</h1>
            <a href="/" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><-Back</a>
        </div>

        <div class="col-6">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="div -invalid-feedback">
                    <div class="alert alert-danger alert dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="div -invalid-feedback">
                    <div class="alert alert-danger alert dismissible fade show" role="alert">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <form method="POST" action="<?php echo e(route('siswa.store')); ?>" >
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="nama" class="form-label">Nama</label>
                  <input type="input" class="form-control" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" required>
                </div>
                <div class="mb-3">
                  <label for="Email" class="form-label">Email</label>
                  <input type="email" class="form-control" id="Email" name="email" value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="mb-3">
                  <label for="nis" class="form-label">NIS</label>
                  <input type="number" class="form-control" id="nis" name="nis" value="<?php echo e(old('nis')); ?>" required>
                </div>
                <div class="mb-3">
                  <label for="tanggal_lahir" class="form-label">Tanggal Lahir</label>
                  <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>" required>
                </div>
                <label for="disabledSelect" class="form-label">Jenis Kelamin</label>
                    <select id="disabledSelect" class="form-select" name="jenis_kelamin" >
                        <option value="Pria">Pria</option>
                        <option value="Wanita">Wanita</option>
                    </select>
                <div class="mb-3">
                  <label for="alamat" class="form-label">Alamat</label>
                  <input type="input" class="form-control" id="alamat" name="alamat" value="<?php echo e(old('alamat')); ?>" required>
                </div>
                

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webapps/resources/views/dashboard/page/siswa/addsiswa.blade.php ENDPATH**/ ?>