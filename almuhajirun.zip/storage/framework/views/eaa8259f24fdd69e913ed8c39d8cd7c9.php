<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('content'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">ADD <?php echo e($title); ?></h1>
            <a href="<?php echo e(route('user.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><-Back</a>
        </div>

        <div class="col-6">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-primary">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('user.store')); ?>" >
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="name" class="form-label">Name</label>
                  <input type="input" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                </div>
                <div class="mb-3">
                  <label for="Email" class="form-label">Email</label>
                  <input type="email" class="form-control" id="Email" name="email" value="<?php echo e(old('email')); ?>" required>
                </div>
                <div class="mb-3">
                <label for="disabledSelect" class="form-label">Role</label>
                    <select id="disabledSelect" class="form-select" name="role" >
                        <option value="Ketua">Ketua</option>
                        <option value="Bendahara">Bendahara</option>
                        <option value="Sekretaris">Sekretaris</option>
                        <option value="Guru">Guru</option>
                    </select>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Laravel\webapps\resources\views/dashboard/page/user/add.blade.php ENDPATH**/ ?>