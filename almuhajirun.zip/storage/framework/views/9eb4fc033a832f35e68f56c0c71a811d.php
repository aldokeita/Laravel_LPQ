<!-- ======= Header ======= -->
<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1 class="text-light"><a href="index.html"><span>LPQ AL-MUHAJIRUN</span></a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="../../../homepage/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto <?php echo e(Request::is('/') ? 'active' : ''); ?>" href="/">Beranda</a></li>
          <li><a class="nav-link scrollto <?php echo e(Request::is('aboutus') ? 'active' : ''); ?>" href="/aboutus">Tentang Kami</a></li>
          
          <li><a class="nav-link scrollto <?php echo e(Request::is('news') ? 'active' : ''); ?>" href="/news">Berita</a></li>
          
          
          <li><a class="nav-link scrollto <?php echo e(Request::is('contactus') ? 'active' : ''); ?>" href="/contactus">Kontak</a></li>
          <?php if(auth()->guard()->check()): ?>
            <li><a class="getstarted scrollto" href="/dashboard">Hi, <?php echo e(auth()->user()->name); ?></a></li>
          <?php else: ?>
            <li><a class="getstarted scrollto" href="/login">Masuk</a></li>
          <?php endif; ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
  <!-- End Header -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webapps/resources/views/homepage/partial/header.blade.php ENDPATH**/ ?>