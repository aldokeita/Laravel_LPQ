<?php $__env->startSection('title','News'); ?>

<?php $__env->startSection('main'); ?>

  <!-- ======= Portfolio Section ======= -->
  <section id="portfolio" class="portfolio">
    <div class="container" data-aos="fade-up">

      <div class="section-title">
        <h2>NEWS</h2>
        <p>Check our Update News</p>
      </div>

      <div class="row" data-aos="fade-up" data-aos-delay="100">
        <div class="col-lg-12">
          <ul id="portfolio-flters">
            <li data-filter="*" class="filter-active">All</li>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-filter=".filter-<?php echo e($item->id); ?>"><?php echo e($item->category); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>

      <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 portfolio-item filter-<?php echo e($item->category_id); ?>">
          <div class="portfolio-wrap">
            <img src="<?php echo e(asset('storage/'.$item->photo)); ?>" class="img-fluid" alt="">
            <div class="portfolio-info">
                <h4><?php echo e($item->title); ?></h4>
                <p><?php echo e(Str::limit($item->content, 50)); ?></p>
            </div>
            <div class="portfolio-links">
              <a href="<?php echo e(asset('storage/'.$item->photo)); ?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="<?php echo e($item->title); ?>"><i class="bi bi-zoom-in"></i></a>
              <a href="news/<?php echo e($item->title); ?>" title="More Details"><i class="bi bi-eye"></i></a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>

    </div>
  </section><!-- End Portfolio Section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('homepage.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Downloads\webapps\resources\views/homepage/page/news.blade.php ENDPATH**/ ?>