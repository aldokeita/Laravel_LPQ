<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e($title); ?></h1>
    </div>
    <a href="<?php echo e(route('kelas.index')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><b><-</b> Back</a>
    <form action="<?php echo e(route('kelas.destroy',1)); ?>" method="POST" class="d-inline">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>

        <button class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm" onclick="return confirm('Hapus berita ?')" type="submit">
            <i class="bi bi-trash3"></i>  Delete
        </button>
    </form>

    
    <div class="col-5 m-10" style="text-align:center">
        <h1><?php echo e($data->kelas); ?></h1>
        <h3>Santri Yang terdaftar</h3>
        <hr>
        <h5>Tambah Santri    </h5>
        <?php if($errors->any()): ?>
            <div style="color: red;">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('addsiswakelas')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <div class="row">
                    <div class="col-8">
                        <select id="disabledSelect" class="form-select" name="siswa_id" >
                            <?php $__currentLoopData = $listsiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-4">
                        <input type="hidden" name="idkelas" value="<?php echo e($data->id); ?>">
                        <input type="hidden" name="kelas" value="<?php echo e($data->kelas); ?>">
                        <button type="submit" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </div>
        </form>
        <hr>

        <div class="table-responsive">
        <table class="table">
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>action</th>
            </tr>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td style="text-align: left">
                        <?php echo e($item->siswa->nama); ?>

                    </td>
                    <td>
                        <form action="<?php echo e(route('deletesiswakelas')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                            <input type="hidden" value="<?php echo e($data->id); ?>" name="idkelas">
                            <button class="badge bg-danger border-0" onclick="return confirm('Apakah anda yakin ?')"><i class="bi bi-trash3"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/webapps/resources/views/dashboard/page/kelas/show.blade.php ENDPATH**/ ?>