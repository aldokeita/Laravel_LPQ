<?php $__env->startSection('title','News'); ?>

<?php $__env->startSection('content'); ?>

<?php dd($news->category); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Laravel\webapps\resources\views/dashboard/page/detailnews.blade.php ENDPATH**/ ?>