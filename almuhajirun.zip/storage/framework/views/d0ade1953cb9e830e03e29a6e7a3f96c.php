<?php $__env->startSection('title','Profile Setting'); ?>

<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Profile Setting</h1>
        <a class="btn btn-primary" href="#" data-toggle="modal" data-target="#ubahpass">
            Ubah Password
        </a>
    </div>
    <div class="col-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <table class="table" >
            <tr>
                <td>Nama</td>
                <td><?php echo e($data->name); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo e($data->email); ?></td>
            </tr>
            <tr>
                <td>Role</td>
                <td><?php echo e($data->role); ?></td>
            </tr>
            <?php if($data->role=='siswa'): ?>
            
                <tr>
                    <td>NIS</td>
                    <td><?php echo e($data->siswa->nis); ?></td>
                </tr>
                <tr>
                    <td>Tanggal Lahir</td>
                    <td><?php echo e($data->siswa->tanggal_lahir); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td><?php echo e($data->siswa->alamat); ?></td>
                </tr>
                <tr>
                    <td>Jenis Kelamin</td>
                    <td><?php echo e($data->siswa->jenis_kelamin); ?></td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

</div>

<!-- Logout Modal-->
<div class="modal fade" id="ubahpass" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ubah Password</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('updatepassword')); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

                    <div class="mb-3">
                        <label for="oldpass" class="form-label">Password Lama</label>
                        <input type="password" name="oldpass" id="oldpass" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="newpass" class="form-label">Password Baru</label>
                        <input type="password" name="newpass" id="newpass"class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Ubah</button>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Downloads\webapps\resources\views/dashboard/page/setting.blade.php ENDPATH**/ ?>